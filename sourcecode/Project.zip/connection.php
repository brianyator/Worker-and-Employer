<?php 
 $con = mysqli_connect("localhost", "root", "","kazi");

 if(!$con){
 	die('Please check connection'.mysql_error());
 }
 ?>