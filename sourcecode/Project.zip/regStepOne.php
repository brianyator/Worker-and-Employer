<html>
<head>
	<title>Worker Interface</title>
	<link rel="stylesheet" type="text/css" href="styleussd.css">
</head>
<body>
	<div class="mobile">
		<div class="top"></div>
		<h1>4:20<span>PM</span><br><span>8th Nov, 2019</span></h1>
		<div id = "USSD" class="USSD">
		
		<form method="post" action="regStepTwo.php">
			<h2>Registration</h2><br><br>
			<p>Enter First Name</p>
			<input type="text" name="txtf" value=""><br>
			<br>
			<input id="submit" type="submit" name="Step2" value="Step2">
		</form>

		</div>
		<div class="bottom"></div>
</body>
</html>