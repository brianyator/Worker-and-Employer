<?php
session_start();
if(isset($_SESSION['name']))
$errors= array();
$db=  mysqli_connect('localhost', 'root', '', 'kazi');

require_once("dbconnect.php");
$connecting = connection();


if (isset($_POST['send'])) {
$location = $_POST['location'];
$time = $_POST['time'];
$name = $_SESSION['name'];
}

  	$query = "INSERT INTO location (name, location, time) 
  			  VALUES('$name', '$location','$time')";

	$insert = mysqli_query($connecting, $query);
	if($insert){
		echo "Details entered successfully. Please wait as we direct you to the nearest available worker...";
		$sql = "SELECT laundry.location AS laundryLocation, laundry.time AS laundryTime, worker.id AS workerId, worker.first_name AS workerFirstName, worker.last_name AS workerLastName, worker.phone_number AS workerPhoneNumber, worker.rate_per_bucket AS workerRate FROM laundry, worker WHERE laundry.location = '$location' AND laundry.time = '$time' AND laundry.id = worker.id";
		$result=mysqli_query($connecting,$sql);

        if($rows = mysqli_fetch_assoc($result))
            {
            	echo " </br></br>Congratulations!</br>";
            	$worker_id = $rows['workerId'];
            	$worker_first_name = $rows['workerFirstName'];
            	$worker_last_name = $rows['workerLastName'];
            	$worker_phone_number = $rows['workerPhoneNumber'];
            	$worker_rate = $rows['workerRate'];
            	$worker_location = $rows['laundryLocation'];
            	$worker_time = $rows['laundryTime'];
            	echo "You have been matched with worker ".$worker_first_name." ".$worker_last_name." with phone number of 0".$worker_phone_number." and a rate of ".$worker_rate." Kenyan Shillings per hour </br>";


            	$sql_del = "DELETE FROM laundry WHERE laundry.location = '$worker_location' AND laundry.time = '$worker_time'";
            	$res = mysqli_query($connecting,$sql_del);
            	
            }
		else
            {
            	echo "</br> Unfortunately there is no match at the moment";
            }
	}
	else
	{
		echo "there was a minor problem with all the connection to various tables";
	}


?>